# BusPass: bus pass management

A very small full-stack workshop project. Log in with a phone OTP, buy a weekly or monthly bus pass, see your passes, cancel one.

- **Frontend:** React (Vite), 3 pages: Login, My passes, Get a pass
- **Backend:** Python (Flask) + SQLite, 5 endpoints
- **OTP:** [Minimoth](https://minimoth.dev) (WhatsApp/SMS), called from the backend only

## Run it

You need Python 3.9+, Node 18+ and a Minimoth API key.

**1. Backend**
```bash
cd backend
python -m venv venv && source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                               # then paste your MINIMOTH_API_KEY
python app.py                                      # http://localhost:5001
```

**2. Frontend** (new terminal)
```bash
cd frontend
npm install
cp .env.example .env
npm run dev                                        # http://localhost:5173
```

Open http://localhost:5173, enter your phone number (10 digits = India `+91`, otherwise include the country code), enter the OTP you receive, and you are in. New numbers also need a name.

## API

| Method | Path | What it does |
|---|---|---|
| POST | `/api/otp/send` | `{phone, name?}` sends an OTP via Minimoth |
| POST | `/api/otp/verify` | `{phone, code, name?}` checks the OTP, registers new users, returns a session `token` |
| GET | `/api/passes` | Your passes (needs `Authorization: Bearer <token>`) |
| POST | `/api/passes` | `{route, plan}` buys a pass (`weekly` ₹250 or `monthly` ₹800) |
| DELETE | `/api/passes/<id>` | Cancels one of your passes |

Database tables: `users`, `sessions`, `passes` (SQLite file `backend/buspass.db`, created on first run).

## Notes

- Minimoth calls (`POST https://api.minimoth.dev/v1/otp/send` and `/verify`, `X-Api-Key` header) follow a public Minimoth client. If your dashboard docs differ, edit the `minimoth()` function in `backend/app.py`.
- The Vite dev server proxies `/api` to the backend (`VITE_BACKEND_URL`), so no CORS setup is needed.
- Log out only clears the token in the browser. Sessions do not expire. Fine for a workshop, not for production.
- The route and plan lists live in both `backend/app.py` and `frontend/src/pages/BuyPass.jsx`.

## Structure
```
backend/   app.py  requirements.txt  .env.example
frontend/  index.html  vite.config.js  .env.example  src/{App,api,styles,pages/*}
```
